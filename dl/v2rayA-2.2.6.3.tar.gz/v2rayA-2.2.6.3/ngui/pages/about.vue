<template>
  <div class="mx-auto w-96">
    <div class="text-2xl font-bold">mzz2017 / v2rayA</div>
    <div class="prose" v-html="$t(`about`)" />
    <a href="https://github.com/v2rayA/v2rayA" target="_blank" class="flex space-x-2">
      <img src="https://img.shields.io/github/stars/mzz2017/v2rayA.svg?style=social" alt="stars">
      <img src="https://img.shields.io/github/forks/mzz2017/v2rayA.svg?style=social" alt="forks">
      <img src="https://img.shields.io/github/watchers/mzz2017/v2rayA.svg?style=social" alt="watchers">
    </a>
  </div>
</template>
