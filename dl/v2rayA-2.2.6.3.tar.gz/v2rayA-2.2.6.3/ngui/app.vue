<template>
  <div>
    <NuxtLayout>
      <NuxtPage />
    </NuxtLayout>
  </div>
</template>

<style>
@import 'element-plus/theme-chalk/dark/css-vars.css';

.el-table .el-table__cell{
  z-index: unset!important;
}
</style>
