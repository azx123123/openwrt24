export const user = useLocalStorage('user', {
  token: '',
  firstCheck: true,
  exist: false
})
