import zh from "./zh";
import en from "./en";
import fa from "./fa-ir";
import ru from "./ru";
import pt from "./pt-br";

export default {
  zh,
  en,
  fa,
  ru,
  pt,
};
