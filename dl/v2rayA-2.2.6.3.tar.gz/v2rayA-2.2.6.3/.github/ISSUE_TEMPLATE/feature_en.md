---
name: Suggest an new feature
about: Suggest an idea for this project
labels: enhancement

---

### Is the feature related with existing problem?
<!-- If is, describe the problem below -->



### Content of the feature
<!-- Describe the feature you suggest below -->


