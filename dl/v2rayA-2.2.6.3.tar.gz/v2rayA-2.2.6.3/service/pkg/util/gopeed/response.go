package gopeed

type Response struct {
	Name  string
	Size  int64
	Range bool
}
