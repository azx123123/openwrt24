package ports

/* socketstat */
//deprecated
func ss() {

}
