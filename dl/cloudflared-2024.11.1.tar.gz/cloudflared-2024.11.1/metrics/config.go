package metrics

type HistogramConfig struct {
	BucketsStart float64
	BucketsWidth float64
	BucketsCount int
}
