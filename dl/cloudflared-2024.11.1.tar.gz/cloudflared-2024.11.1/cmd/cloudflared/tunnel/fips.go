package tunnel

var FipsEnabled bool
